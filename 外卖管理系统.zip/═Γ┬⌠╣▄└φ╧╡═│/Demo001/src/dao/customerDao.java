package dao;

import entity.*;
import utils.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class customerDao {
    private static  final String url="jdbc:mysql://localhost:3306/waimai?characterEncoding=utf-8";
    //查询指定商品，找不到返回空集合
    public static List<tea> selectea(String a){

        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<tea> l=new ArrayList<>();
        int index=0;

        try{
            String sql="select * from tea where business_cp=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setString(1,a);
            ResultSet r=s.executeQuery();
            while (r.next()){
                l.add(new tea(
                        r.getString("business_name"),
                        r.getString("business_cp"),
                        r.getString("business_type"),
                        r.getString("time")
                ));
            }
            DBUtil.close(conn,s,r);
        }catch (SQLException e){
            e.printStackTrace();
        }

        return l;
    }

    //查询商品

    public static List<tea> selectalltea(){

        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<tea> l=new ArrayList<>();
        try{
            String sql="select * from tea";
            PreparedStatement s=conn.prepareStatement(sql);
            ResultSet r=s.executeQuery();
            while (r.next()){
                l.add(new tea(
                        r.getInt("id"),
                        r.getString("business_name"),
                        r.getString("business_cp"),
                        r.getString("business_type"),
                        r.getString("time")

                ));
            }
            DBUtil.close(conn,s,r);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return l;
    }

    //修改指定订单状态
    public  static  int updatastate(int i){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="update record set state=4 where id=?";
            PreparedStatement  p=conn.prepareStatement(sql);

            p.setInt(1,i);

            num=p.executeUpdate();
            DBUtil.close(conn,p,null);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }

    //查询订单信息
    public static List<record> selectallrecord(){

        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<record> l=new ArrayList<>();
        try{
            String sql="select * from record";
            PreparedStatement s=conn.prepareStatement(sql);
            ResultSet r=s.executeQuery();
            while (r.next()){
                l.add(new record(
                        r.getInt("id"),
                        r.getString("tea_name"),
                        r.getString("tea_type"),

                        r.getString("userName"),
                        r.getString("time"),
                        r.getString("state"),
                        r.getString("psrName")
                ));
            }
            DBUtil.close(conn,s,r);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return l;
    }

    //查询指定订单
    public static List<record> selectonerecord(String name){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
       List<record> list=new ArrayList<>();
String username=selectname(name);
        try{
            String sql="select * from record where userName=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setString(1,username);
            ResultSet r=s.executeQuery();
            while (r.next()){
                list.add(new record(
                        r.getInt("id"),
                        r.getString("tea_name"),
                        r.getString("tea_type"),
                        r.getString("userName"),
                        r.getString("time"),
                        r.getString("state"),
                        r.getString("psrName")
                ));
            }
            DBUtil.close(conn,s,r);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return list;
    }
//添加订单
public static int recordadd(String tea_name,String tea_type,String name){
    Connection conn=DBUtil.getConnnection(url,"root","123456");
    int num=0;
    if(tea_name!=null&&tea_type!=null&&name!=null){
        String username=selectname(name);
       LocalDateTime dateTime = LocalDateTime.now();
       DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-dd-MM HH:mm:ss");
       String noa=customerDao.createOrderCode();
       try{
           String sql="insert into record(tea_name,tea_type,no,username,time,state,psrName) values(?,?,?,?,?,?,?)";
           PreparedStatement p =conn.prepareStatement(sql);
           p.setString(1,tea_name);
           p.setString(2,tea_type);
           p.setString(3,noa);
           p.setString(4,username);
           p.setString(5,dateTime.format(formatter));
           p.setString(6,"1");
           p.setString(7,"无");

           num=p.executeUpdate();
           DBUtil.close(conn,p,null);
       }catch (SQLException e){
           e.printStackTrace();
       }
   }else {
        System.out.println("value null");
    }

    return num;
}

//生成编号
public static String createOrderCode() {
    LocalDateTime dateTime = LocalDateTime.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-dd-MM HH:mm:ss");
    String code = dateTime.format(formatter);
    //随机生成四位数
    String timeMillis = System.currentTimeMillis() + "";
    String randomNum = timeMillis.substring(timeMillis.length() - 4);

    //生成订单编号
    String orderCode = code + randomNum;

    return orderCode;
}

//根据传的用户账号找到对应的用户名
public static String selectname(String name){
    Connection conn= DBUtil.getConnnection(url,"root","123456");
String username=null;
    int index=0;
    try{
        String sql="select customer_name from customer where customer_no=?";
        PreparedStatement s=conn.prepareStatement(sql);
        s.setString(1,name);
        ResultSet r=s.executeQuery();
        while (r.next()){
           username=r.getString("customer_name");
        }
        DBUtil.close(conn,s,r);
    }catch (SQLException e){
        e.printStackTrace();
    }
    return username;
}

//购物车添加订单

public static int recordcatadd(String tea_name,String tea_type,String name) {
    Connection conn = DBUtil.getConnnection(url, "root", "123456");
    int num = 0;

    LocalDateTime dateTime = LocalDateTime.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-dd-MM HH:mm:ss");
    String noa = customerDao.createOrderCode();
    try {
        String sql = "insert into record(tea_name,tea_type,no,username,time,state,psrName) values(?,?,?,?,?,?,?)";
        PreparedStatement p = conn.prepareStatement(sql);
        p.setString(1, tea_name);
        p.setString(2, tea_type);
        p.setString(3, noa);
        p.setString(4, name);
        p.setString(5, dateTime.format(formatter));
        p.setString(6, "1");
        p.setString(7, "无");

        num = p.executeUpdate();
        DBUtil.close(conn, p, null);
    } catch (SQLException e) {
        e.printStackTrace();
    }


    return num;
}

//加入购物车

public static int catadd(String tea_name,String tea_type,String name){
    Connection conn=DBUtil.getConnnection(url,"root","123456");
    int num=0;
        String username=selectname(name);
        LocalDateTime dateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-dd-MM HH:mm:ss");
        String noa=customerDao.createOrderCode();
        try{
            String sql="insert into cat(tea_name,tea_type,username,time) values(?,?,?,?)";
            PreparedStatement p =conn.prepareStatement(sql);
            p.setString(1,tea_name);
            p.setString(2,tea_type);
            p.setString(3,username);
            p.setString(4,dateTime.format(formatter));
            num=p.executeUpdate();
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
        }


    return num;
}

//查询订单信息
public static List<cat> selectcat(){

    Connection conn= DBUtil.getConnnection(url,"root","123456");
    List<cat> l=new ArrayList<>();
    try{
        String sql="select * from cat";
        PreparedStatement s=conn.prepareStatement(sql);
        ResultSet r=s.executeQuery();
        while (r.next()){
            l.add(new cat(
                    r.getInt("id"),
                    r.getString("tea_name"),
                    r.getString("tea_type"),
                    r.getString("userName"),
                    r.getString("time")
            ));
        }
        DBUtil.close(conn,s,r);

    }catch (SQLException e){
        e.printStackTrace();
    }
    return l;
}

//删除购物车
public static int delecat(int id) {
    Connection conn = DBUtil.getConnnection(url, "root", "123456");
    int num = 0;
    try {
        String sql = "delete from cat where id=?";
        PreparedStatement p = conn.prepareStatement(sql);
        p.setInt(1, id);
        num = p.executeUpdate();
        DBUtil.close(conn, p, null);
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return num;
}

//查看指定商品

public static tea selectgoods(String a){
    Connection conn= DBUtil.getConnnection(url,"root","123456");
    tea r1=null;
    try{
        String sql="select * from tea where business_cp=?";

        PreparedStatement s=conn.prepareStatement(sql);
        s.setString(1,a);
        ResultSet r=s.executeQuery();
        while (r.next()){
            r1=new tea(
                    r.getInt("id"),
                    r.getString("business_name"),
                    r.getString("business_cp"),
                    r.getString("business_type"),
                    r.getInt("business_id"),
                    r.getString("time")
            );
        }
        DBUtil.close(conn,s,r);



    }catch (SQLException e){
        e.printStackTrace();
    }

    return r1;
}




}
