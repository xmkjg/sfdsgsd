package dao;

import entity.*;
import utils.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class businessDao {
    private static  final String url="jdbc:mysql://localhost:3306/waimai?characterEncoding=utf-8";

    //查询指定商品，找不到返回空集合
    public static List<tea> selectea(String a){

        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<tea> l=new ArrayList<>();
        int index=0;

        try{
            String sql="select * from tea where business_cp=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setString(1,a);
            ResultSet r=s.executeQuery();
            while (r.next()){
                l.add(new tea(
                        r.getString("business_name"),
                        r.getString("business_cp"),
                        r.getString("business_type"),
                        r.getString("time")
                ));
            }
            DBUtil.close(conn,s,r);
        }catch (SQLException e){
            e.printStackTrace();
        }

        return l;
    }


    //新增商品
    public static int teaadd(String tea_name,String tea_type,String positon){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        LocalDateTime dateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-dd-MM HH:mm:ss");

        try{
            String sql="insert into tea(business_name,business_cp,business_type,time) values(?,?,?,?)";
            PreparedStatement p= conn.prepareStatement(sql);
            p.setString(1,positon);
            p.setString(2,tea_name);
            p.setString(3,tea_type);
            p.setString(4,dateTime.format(formatter));
            num=p.executeUpdate();
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }


    //删除商品
    public static int deletea(int i){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="delete from tea where id=?";
            PreparedStatement p= conn.prepareStatement(sql);
            p.setInt(1,i);
            num= p.executeUpdate();
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }
    //删除三个属性相同的商品
    public static int delethreetea(String business_name,String business_type,String business_cp){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="delete from tea where business_name=? and business_type=? and business_cp=? ";
            PreparedStatement p= conn.prepareStatement(sql);
            p.setString(1,business_name);
            p.setString(2,business_type);
            p.setString(3,business_cp);
            num= p.executeUpdate();
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }

//商家接单

    //查询指定订单
public static List<record> selectrecord(String a){
    Connection conn= DBUtil.getConnnection(url,"root","123456");
    List<record> l=new ArrayList<>();
    int index=0;
    try{
        String sql="select * from record where userName=?";
        PreparedStatement s=conn.prepareStatement(sql);
        s.setString(1,a);
        ResultSet r=s.executeQuery();
        while (r.next()){
            l.add(new record(
                    r.getString("tea_name"),
                    r.getString("tea_type"),
                    r.getString("no"),
                    r.getString("userName"),
                    r.getInt("userId"),
                    r.getString("time"),
                    r.getString("state"),
                    r.getInt("psrId"),
                    r.getString("psrName")
            ));
        }
        DBUtil.close(conn,s,r);



    }catch (SQLException e){
        e.printStackTrace();
    }

    return l;
}

    //查询订单信息
    public static List<record> selectallrecord(){

        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<record> l=new ArrayList<>();
        try{
            String sql="select * from record";
            PreparedStatement s=conn.prepareStatement(sql);
            ResultSet r=s.executeQuery();
            while (r.next()){
                l.add(new record(
                        r.getInt("id"),
                        r.getString("tea_name"),
                        r.getString("tea_type"),
                        r.getString("no"),
                        r.getString("userName"),
                        r.getString("time"),
                        r.getString("state"),
                        r.getString("psrName")

                ));
            }
            DBUtil.close(conn,s,r);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return l;
    }

    //修改指定订单状态
    public  static  int updatastate(int i){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="update record set state=2 where id=?";
            PreparedStatement  p=conn.prepareStatement(sql);

            p.setInt(1,i);

            num=p.executeUpdate();
            DBUtil.close(conn,p,null);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }

    public  static  int updataserchstate(String no,String state){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="update record set state=2 where no=? and state=?";
            PreparedStatement  p=conn.prepareStatement(sql);

            p.setString(1,no);
            p.setString(2,state);

            num=p.executeUpdate();
            DBUtil.close(conn,p,null);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }

//查询指定订单状态
    public static List<tea> selectonerecords(String name){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<tea> l=new ArrayList<>();

        try{
            String sql="select * from tea where business_cp=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setString(1,name);
            ResultSet r=s.executeQuery();
            while (r.next()){
                l.add(new tea(
                        r.getString("business_name"),
                        r.getString("business_cp"),
                        r.getString("business_type"),
                        r.getString("time")
                ));
            }
            DBUtil.close(conn,s,r);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return l;
    }






}
