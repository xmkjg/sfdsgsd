package dao;

import entity.record;
import utils.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class loginDao {
    private static  final String url="jdbc:mysql://127.0.0.1:3306/waimai";
//管理端登录
    public static boolean select(String username,String psw){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        boolean is=false;
        try{
            String sql="select * from admin where userName=? and pwd=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setString(1,username);
            s.setString(2,psw);
            ResultSet r=s.executeQuery();
          if (r.next()) {
              is=true;
              System.out.println("success");
          }else {
              is=false;
              System.out.println(" login err!");
          }
            DBUtil.close(conn,s,r);
        }catch (SQLException e){
            e.printStackTrace();
            System.out.println("not!");
        }
        return is;
    }

//客户端登录

    public static boolean selectcus(String username,String psw){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        boolean is=false;
        try{
            String sql="select * from customer where customer_no=? and customer_pwd=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setString(1,username);
            s.setString(2,psw);
            ResultSet r=s.executeQuery();
            if (r.next()) {
                is=true;
                System.out.println("success");
            }else {
                is=false;
                System.out.println(" login err!");
            }
            DBUtil.close(conn,s,r);
        }catch (SQLException e){
            e.printStackTrace();
            System.out.println("not!");
        }
        return is;
    }

    //商家端登录

    public static boolean selectbus(String username,String psw){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        boolean is=false;
        try{
            String sql="select * from business where business_no=? and business_pwd=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setString(1,username);
            s.setString(2,psw);
            ResultSet r=s.executeQuery();
            if (r.next()) {
                is=true;
                System.out.println("success");
            }else {
                is=false;
                System.out.println(" login err!");
            }
            DBUtil.close(conn,s,r);
        }catch (SQLException e){
            e.printStackTrace();
            System.out.println("not!");
        }
        return is;
    }

//骑手端登录
public static boolean selectpsr(String username,String psw){
    Connection conn= DBUtil.getConnnection(url,"root","123456");
    boolean is=false;
    try{
        String sql="select * from psr where psy=? and pwd=?";
        PreparedStatement s=conn.prepareStatement(sql);
        s.setString(1,username);
        s.setString(2,psw);
        ResultSet r=s.executeQuery();
        if (r.next()) {
            is=true;
            System.out.println("success");
        }else {
            is=false;
            System.out.println(" login err!");
        }
        DBUtil.close(conn,s,r);
    }catch (SQLException e){
        e.printStackTrace();
        System.out.println("not!");
    }
    return is;
}

}
