package dao;

import entity.psr;
import entity.record;
import utils.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class psrDao {
    private static  final String url="jdbc:mysql://localhost:3306/waimai?characterEncoding=utf-8";
    //查询订单信息
    public static List<record> selectallrecord(){

        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<record> l=new ArrayList<>();
        try{
            String sql="select * from record";
            PreparedStatement s=conn.prepareStatement(sql);
            ResultSet r=s.executeQuery();
            while (r.next()){
                l.add(new record(
                        r.getString("tea_name"),
                        r.getString("tea_type"),
                        r.getString("no"),
                        r.getString("userName"),
                        r.getInt("userId"),
                        r.getString("time"),
                        r.getString("state"),
                        r.getInt("psrId"),
                        r.getString("psrName")

                ));
            }
            DBUtil.close(conn,s,r);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return l;
    }

    //查询指定订单
    public static List<record> selectrecord(String a){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<record> l=new ArrayList<>();
        int index=0;
        try{
            String sql="select * from record where psrName=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setString(1,a);
            ResultSet r=s.executeQuery();
            while (r.next()){
                l.add(new record(
                        r.getString("tea_name"),
                        r.getString("tea_type"),
                        r.getString("no"),
                        r.getString("userName"),
                        r.getInt("userId"),
                        r.getString("time"),
                        r.getString("state"),
                        r.getInt("psrId"),
                        r.getString("psrName")
                ));
            }
            DBUtil.close(conn,s,r);



        }catch (SQLException e){
            e.printStackTrace();
        }

        return l;
    }


    //修改指定订单状态
    public  static  int updatastate(String psrname,int i){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="update record set state=3,psrName=? where id=?";
            PreparedStatement  p=conn.prepareStatement(sql);
            p.setString(1,psrname);
            p.setInt(2,i);


            num=p.executeUpdate();
            DBUtil.close(conn,p,null);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }




    //查询指定订单状态
    public static List<record> selectrecordstate(record c){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<record> l=new ArrayList<>();
        int index=0;
        try{
            String sql="select state from record where id=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setInt(1,c.getId());
            ResultSet r=s.executeQuery();
            while (r.next()){
                l.add(new record(
                        r.getString("state")
                ));
            }
            DBUtil.close(conn,s,r);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return l;
    }


    //查询骑手
    public static List<psr> selectpsr(record c){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<psr> l=new ArrayList<>();
        int index=0;
        try{
            String sql="select * from psr where id=(select psrId from business where id=?)";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setInt(1,c.getId());
            ResultSet r=s.executeQuery();
            while (r.next()){
                l.add(new psr(
                        r.getString("psy")
                ));
            }
            DBUtil.close(conn,s,r);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return l;
    }
//修改配送人
    public  static  int updatapsy(record r){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="update record set psyId=(select psy from psr where id=(select psrId from record where id=?)) where id=?";
            PreparedStatement  p=conn.prepareStatement(sql);
            p.setInt(1,r.getId());
            p.setInt(2,r.getId());
            num=p.executeUpdate();
            DBUtil.close(conn,p,null);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }


}
