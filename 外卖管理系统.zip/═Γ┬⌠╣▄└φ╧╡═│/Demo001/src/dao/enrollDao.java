package dao;

import entity.admin;
import entity.tea;
import utils.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class enrollDao {
    private static  final String url="jdbc:mysql://127.0.0.1:3306/waimai";
//管理端注册
    public static void enrolladmin(String username,String pwd,String name){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="insert into admin(userName,nickName,pwd) values(?,?,?)";
            PreparedStatement p =conn.prepareStatement(sql);
            p.setString(1,username);
            p.setString(2,name);
            p.setString(3,pwd);
            num=p.executeUpdate();
            if(num>0){
                System.out.println("添加成功");
            }
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
            System.out.println("err");
        }

    }
//客户注册
    public static void enrollcus(String username,String pwd,String name){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        int num=0;
        LocalDateTime dateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        try{
            String sql="insert into customer(customer_name,customer_no,customer_pwd,time) values(?,?,?,?)";
            PreparedStatement p =conn.prepareStatement(sql);
            p.setString(1,name);
            p.setString(2,username);
            p.setString(3,pwd);
            p.setString(4,dateTime.format(formatter));
            num=p.executeUpdate();
            if(num>0){
                System.out.println("添加成功");
            }
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
            System.out.println("err");
        }

    }

//商家端注册
    public static void enrollbus(String username,String pwd,String name,String business){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        int num=0;
        LocalDateTime dateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        try{
            String sql="insert into business(business_name,business_person,business_no,business_pwd,time) values(?,?,?,?,?)";
            PreparedStatement p =conn.prepareStatement(sql);
            p.setString(1,business);
            p.setString(2,name);
            p.setString(3,username);
            p.setString(4,pwd);
            p.setString(5, dateTime.format(formatter));

            num=p.executeUpdate();
            if(num>0){
                System.out.println("添加成功");
            }
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
            System.out.println("err");
        }

    }

//骑手注册
public static void enrollpsr(String psy,String pwd,String phone){
    Connection conn= DBUtil.getConnnection(url,"root","123456");
    int num=0;
    LocalDateTime dateTime = LocalDateTime.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    try{
        String sql="insert into psr(psy,pwd,phone,time) values(?,?,?,?)";
        PreparedStatement p =conn.prepareStatement(sql);
        p.setString(1,psy);
        p.setString(2,pwd);
        p.setString(3,phone);
        p.setString(4, dateTime.format(formatter));

        num=p.executeUpdate();
        if(num>0){
            System.out.println("add success");
        }
        DBUtil.close(conn,p,null);
    }catch (SQLException e){
        e.printStackTrace();
        System.out.println("err");
    }

}




}
