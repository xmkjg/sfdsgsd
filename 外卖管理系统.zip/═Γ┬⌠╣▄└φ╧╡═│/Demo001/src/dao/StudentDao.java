package dao;

import entity.student;
import utils.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StudentDao {
    private static  final String url="jdbc:mysql://localhost:3306/waimai?characterEncoding=utf-8";

    //查询指定学生信息
    public static List<student> selectstudent(int i){

        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<student> l=new ArrayList<>();
        try{
            String sql="select * from student where id=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setInt(1,i);
            ResultSet r=s.executeQuery();
            while (r.next()){
                l.add(new student(
                        r.getInt("student_id"),
                        r.getString("student_name"),
                        r.getString("student_college"),
                        r.getString("student_major"),
                        r.getInt("student_class"),
                        r.getString("student_tele")

                ));
            }
            DBUtil.close(conn,s,r);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return l;

    }


}
