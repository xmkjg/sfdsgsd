package dao;

import entity.*;
import utils.DBUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
//管理员
public class DriverManagerDao {
    private static  final String url="jdbc:mysql://localhost:3306/waimai?characterEncoding=utf-8";

//查询商家
    public static List<business> selectallbus(){

        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<business> l=new ArrayList<>();
        try{
            String sql="select * from business";
           PreparedStatement s=conn.prepareStatement(sql);
          ResultSet r=s.executeQuery();
          while (r.next()){
              l.add(new business(
                      r.getInt("id"),
                      r.getString("business_name"),
                      r.getString("business_person"),
                      r.getString("time"),
                      r.getString("business_no"),
                      r.getString("business_pwd")
                      ));
          }
          DBUtil.close(conn,s,r);

        }catch (SQLException e){
            e.printStackTrace();
        }

        return l;
    }
//查询指定商家,如果不存在返回空集合
public static business selectbus(String a){

    Connection conn= DBUtil.getConnnection(url,"root","123456");
    business b=null;
    int index=0;

    try{
            String sql="select * from business where business_person=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setString(1,a);
            ResultSet r=s.executeQuery();
            while (r.next()){
                b=new business(
                        r.getString("business_name"),
                        r.getString("business_person"),
                        r.getString("time"),
                        r.getString("business_no"),
                        r.getString("business_pwd")
                );
            }
            DBUtil.close(conn,s,r);



    }catch (SQLException e){
        e.printStackTrace();
    }

    return b;
}



//查询顾客
    public static List<customer> selectallcus(){

        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<customer> l=new ArrayList<>();
        try{
            String sql="select * from customer";
            PreparedStatement s=conn.prepareStatement(sql);
            ResultSet r=s.executeQuery();
            while (r.next()){
                l.add(new customer(
                        r.getInt("id"),
                        r.getString("customer_name"),
                        r.getString("customer_no"),
                        r.getString("customer_pwd"),
                        r.getString("time")

                ));
            }
            DBUtil.close(conn,s,r);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return l;
    }
//查询指定顾客,如果不存在返回空集合
public static customer selectonecus(String a){

    Connection conn= DBUtil.getConnnection(url,"root","123456");
   customer c=null;
    int index=0;

    try{
            String sql="select * from customer where customer_name=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setString(1,a);
            ResultSet r=s.executeQuery();
            while (r.next()){
                c=new customer(

                        r.getString("customer_name"),
                        r.getString("customer_no"),
                        r.getString("customer_pwd"),
                        r.getString("time")
                );
            }
            DBUtil.close(conn,s,r);



    }catch (SQLException e){
        e.printStackTrace();
    }

    return c;
}

    //查询指定商家id,找不到返回空集合
    public static customer selectonecus(int id){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        customer c=null;
        try{
            String sql="select * from customer where id=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setInt(1,id);
            ResultSet r=s.executeQuery();
            while (r.next()){
                c=new customer(
                        r.getInt("id"),
                        r.getString("customer_name"),
                        r.getString("customer_no"),
                        r.getString("customer_pwd"),
                        r.getString("time")
                );
            }
            DBUtil.close(conn,s,r);



        }catch (SQLException e){
            e.printStackTrace();
        }
        System.out.println(c);
        return c;
    }





    //查询订单信息
public static List<record> selectallrecord(){

    Connection conn= DBUtil.getConnnection(url,"root","123456");
    List<record> l=new ArrayList<>();
    try{
        String sql="select * from record";
        PreparedStatement s=conn.prepareStatement(sql);
        ResultSet r=s.executeQuery();
        while (r.next()){
            l.add(new record(
                    r.getInt("id"),
                    r.getString("tea_name"),
                    r.getString("tea_type"),
                    r.getString("no"),
                    r.getString("userName"),
                    r.getString("time"),
                    r.getString("state"),
                    r.getString("psrName")

            ));
        }
        DBUtil.close(conn,s,r);

    }catch (SQLException e){
        e.printStackTrace();
    }
    return l;
}
//查询指定订单，找不到返回空集合
    public static List<record> selectrecord(String a){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<record> r1=new ArrayList<>();
        try{
                String sql="select * from record where tea_name=?";
                PreparedStatement s=conn.prepareStatement(sql);
                s.setString(1,a);
                ResultSet r=s.executeQuery();
                while (r.next()){
                    r1.add(new record(
                            r.getInt("id"),
                            r.getString("tea_name"),
                            r.getString("tea_type"),
                            r.getString("no"),
                            r.getString("userName"),

                            r.getString("time"),
                            r.getString("state"),

                            r.getString("psrName")
                    ));
                }
                DBUtil.close(conn,s,r);



        }catch (SQLException e){
            e.printStackTrace();
        }

        return r1;
    }







//查询配送人
public static List<psr> selectallpsr(){

    Connection conn= DBUtil.getConnnection(url,"root","123456");
    List<psr> l=new ArrayList<>();
    try{
        String sql="select * from psr";
        PreparedStatement s=conn.prepareStatement(sql);
        ResultSet r=s.executeQuery();
        while (r.next()){
            l.add(new psr(
                    r.getInt("id"),
                    r.getString("psy"),
                    r.getString("pwd"),
                    r.getString("phone"),
                    r.getString("time")

            ));
        }
        DBUtil.close(conn,s,r);

    }catch (SQLException e){
        e.printStackTrace();
    }
    return l;
}
//查询指定配送员,如果不存在返回空集合
public static psr selectpsr(String a){
    Connection conn= DBUtil.getConnnection(url,"root","123456");
    psr p=null;
    try{
            String sql="select * from psr where psy=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setString(1,a);
            ResultSet r=s.executeQuery();
            while (r.next()){
                p=new psr(

                        r.getString("psy"),
                        r.getString("pwd"),
                        r.getString("phone"),
                        r.getString("time")
                );
            }
            DBUtil.close(conn,s,r);



    }catch (SQLException e){
        e.printStackTrace();
    }

    return p;
}
    //查询指定配送员id,找不到返回空集合
    public static psr selectonepsr(int id){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        psr p=null;
        try{
            String sql="select * from psr where id=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setInt(1,id);
            ResultSet r=s.executeQuery();
            while (r.next()){
                p=new psr(
                        r.getInt("id"),
                        r.getString("psy"),
                        r.getString("pwd"),
                        r.getString("phone"),
                        r.getString("time")

                );
            }
            DBUtil.close(conn,s,r);



        }catch (SQLException e){
            e.printStackTrace();
        }
        System.out.println(p);
        return p;
    }







    //查询商品
public static List<tea> selectalltea(){

    Connection conn= DBUtil.getConnnection(url,"root","123456");
    List<tea> l=new ArrayList<>();
    try{
        String sql="select * from tea";
        PreparedStatement s=conn.prepareStatement(sql);
        ResultSet r=s.executeQuery();
        while (r.next()){
            l.add(new tea(
                    r.getInt("id"),
                    r.getString("business_name"),
                    r.getString("business_cp"),
                    r.getString("business_type"),
                    r.getInt("business_id"),
                    r.getString("time")

            ));
        }
        DBUtil.close(conn,s,r);

    }catch (SQLException e){
        e.printStackTrace();
    }
    return l;
}
//查询指定商品,找不到返回空集合
    public static List<tea> selectea(String a){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        List<tea> l=new ArrayList<>();
        try{
                String sql="select * from business where business_cp=?";
                PreparedStatement s=conn.prepareStatement(sql);
                s.setString(1,a);
                ResultSet r=s.executeQuery();
                while (r.next()){
                    l.add(new tea(
                            r.getString("business_name"),
                            r.getString("business_cp"),
                            r.getString("business_type"),
                            r.getInt("business_id"),
                            r.getString("time")
                    ));
                }
                DBUtil.close(conn,s,r);



        }catch (SQLException e){
            e.printStackTrace();
        }

        return l;
    }

    //查询指定商家id,找不到返回空集合
    public static business selectonebus(int id){
        Connection conn= DBUtil.getConnnection(url,"root","123456");
        business b=null;
        try{
            String sql="select * from business where id=?";
            PreparedStatement s=conn.prepareStatement(sql);
            s.setInt(1,id);
            ResultSet r=s.executeQuery();
            while (r.next()){
                b=new business(
                        r.getInt("id"),
                        r.getString("business_name"),
                        r.getString("business_person"),
                        r.getString("time"),
                        r.getString("business_no"),
                        r.getString("business_pwd")
                );
            }
            DBUtil.close(conn,s,r);



        }catch (SQLException e){
            e.printStackTrace();
        }
        System.out.println(b);
        return b;
    }



//添加顾客

    public static int customeradd(customer c){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        LocalDateTime dateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-dd-MM HH:mm:ss");
        try{
            String sql="insert into customer(customer_name,customer_no,customer_pwd,time) values(?,?,?,?)";
           PreparedStatement p =conn.prepareStatement(sql);
           p.setString(1,c.getCustomer_name());
            p.setString(2,c.getCustomer_no());
            p.setString(3,c.getCustomer_pwd());
            p.setString(4,dateTime.format(formatter));
          num=p.executeUpdate();
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }

    //添加商家
    public static int businessadd(business  b){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        LocalDateTime dateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-dd-MM HH:mm:ss");

        try{
            String sql="insert into business(business_name,business_person,time,business_no,business_pwd) values(?,?,?,?,?)";
            PreparedStatement p =conn.prepareStatement(sql);
            p.setString(1,b.getBusiness_name());
            p.setString(2,b.getBusiness_person());
            p.setString(3,dateTime.format(formatter));
            p.setString(4,b.getBusiness_no());
            p.setString(5,b.getBusiness_pwd());
            num=p.executeUpdate();
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }



    //添加配送人
    public static int psradd(psr  s){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        LocalDateTime dateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        try{
            String sql="insert into psr(psy,pwd,phone,time) values(?,?,?,?)";
            PreparedStatement p =conn.prepareStatement(sql);

            p.setString(1,s.getPsy());
            p.setString(2,s.getPwd());
            p.setString(3,s.getPhone());
            p.setString(4,dateTime.format(formatter));

            num=p.executeUpdate();
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }


    //修改商家
    public  static  int updatabusiness(business b){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int a=0;
        try{
            String sql="update business set business_name=?,business_person=?,business_no=?,business_pwd=? where id=?";
          PreparedStatement  p=conn.prepareStatement(sql);
          p.setString(1,b.getBusiness_name());
          p.setString(2,b.getBusiness_person());
          p.setString(3,b.getBusiness_no());
          p.setString(4,b.getBusiness_pwd());
          p.setInt(5,b.getId());
          a=p.executeUpdate();
          DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
            System.out.println("err");
        }
        System.out.println(a);
        return a;
    }
//修改顾客
    public  static  int updatacustomer(customer c){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="update customer set customer_name=?,customer_no=?,customer_pwd=?where id=?";

            PreparedStatement  p=conn.prepareStatement(sql);
            p.setString(1,c.getCustomer_name());
            p.setString(2,c.getCustomer_no());
            p.setString(3,c.getCustomer_pwd());
            p.setInt(4,c.getId());
            num=p.executeUpdate();
            DBUtil.close(conn,p,null);

        }catch (SQLException e){
            e.printStackTrace();
        }

        return num;
    }
//修改配送员密码
    public  static  int updatapsr(psr x){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="update psr set pwd=? where id=?";

            PreparedStatement  p=conn.prepareStatement(sql);
            p.setString(1,x.getPwd());
            p.setInt(2,x.getId());

            num=p.executeUpdate();
            DBUtil.close(conn,p,null);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }

    //删除商家
    public static int delebusiness(int id){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="delete from business where id=?";
           PreparedStatement p= conn.prepareStatement(sql);
           p.setInt(1,id);
         num= p.executeUpdate();
         DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }
//删除顾客
    public static int delecustomer(int i){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="delete from customer where id=?";
            PreparedStatement p= conn.prepareStatement(sql);
            p.setInt(1,i);
            num= p.executeUpdate();
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }
//删除配送员
    public static int delepsr(int i){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="delete from psr where id=?";
            PreparedStatement p= conn.prepareStatement(sql);
            p.setInt(1,i);
            num= p.executeUpdate();
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }
//删除商品
    public static int deletea(int i){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="delete from tea where id=?";
            PreparedStatement p= conn.prepareStatement(sql);
            p.setInt(1,i);
            num= p.executeUpdate();
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }
//删除订单
    public static int delerecord(int i){
        Connection conn=DBUtil.getConnnection(url,"root","123456");
        int num=0;
        try{
            String sql="delete from record where id=?";
            PreparedStatement p= conn.prepareStatement(sql);
            p.setInt(1,i);
            num= p.executeUpdate();
            DBUtil.close(conn,p,null);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return num;
    }



}
