package ser;

import dao.DriverManagerDao;
import entity.business;
import entity.record;
import entity.tea;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Servlet_recorddrop", value = "/Servlet_recorddrop")
public class Servlet_recorddrop extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        List<record> list= DriverManagerDao.selectallrecord();
        System.out.println(list);
        request.setAttribute("list",list);
        request.getRequestDispatcher("record.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
