package ser;

import dao.businessDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_takerecord2", value = "/Servlet_takerecord2")
public class Servlet_takerecord2 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id=request.getParameter("id2");
        int num= businessDao.updatastate(Integer.parseInt(id));
        if(num>0){
            System.out.println("success");
        }else {
            System.out.println("take out");
        }
        response.sendRedirect("Servlet_busonerecord");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
