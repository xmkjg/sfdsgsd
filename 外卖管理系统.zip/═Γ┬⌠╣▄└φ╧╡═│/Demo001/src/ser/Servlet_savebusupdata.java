package ser;

import dao.DriverManagerDao;
import entity.business;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_savebusupdata", value = "/Servlet_savebusupdata")
public class Servlet_savebusupdata extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
request.setCharacterEncoding("utf-8");
        String id=request.getParameter("id");
String name=request.getParameter("business_name");
        String person=request.getParameter("business_person");
        String username=request.getParameter("business_no");
        String password=request.getParameter("business_pwd");
        System.out.println(id+name+person+username+password);
      business b=  new business();
      b.setId(Integer.parseInt(id));
      b.setBusiness_name(name);
      b.setBusiness_person(person);
      b.setBusiness_no(username);
      b.setBusiness_pwd(password);
        System.out.println(b.getId()+b.getBusiness_name()+b.getBusiness_person()+b.getBusiness_no()+b.getBusiness_pwd());
       int a=DriverManagerDao.updatabusiness(b);
       if(a==1){
           request.setAttribute("sucess","保存成功");
           System.out.println("sucess");
       }else {
           request.setAttribute("danger","保存失败");
           System.out.println("danger");
       }
       response.sendRedirect("Servlet_busdrop");

    }
}
