package ser;

import dao.businessDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_busaddtea", value = "/Servlet_busaddtea")
public class Servlet_busaddtea extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String tea_name=request.getParameter("tea_name");
        String tea_type=request.getParameter("tea_type");
        String position=request.getParameter("position");
        System.out.println(tea_name+tea_type+position);
      int num=  businessDao.teaadd(tea_name,tea_type,position);
      if(num>0){
          System.out.println("success");
      }else {
          System.out.println("add out");
      }
response.sendRedirect("Servlet_businessdrop");
    }
}
