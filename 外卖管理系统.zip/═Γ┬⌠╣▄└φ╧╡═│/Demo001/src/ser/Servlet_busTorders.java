package ser;

import dao.DriverManagerDao;
import dao.businessDao;
import entity.record;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Servlet_busTorders", value = "/Servlet_busTorders")
public class Servlet_busTorders extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        List<record> list= businessDao.selectallrecord();
        System.out.println(list+"....");
        request.setAttribute("list",list);
        request.getRequestDispatcher("busTorders.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
