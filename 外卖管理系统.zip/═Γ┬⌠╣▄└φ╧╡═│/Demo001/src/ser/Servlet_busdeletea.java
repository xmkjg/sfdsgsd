package ser;

import dao.DriverManagerDao;
import dao.businessDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_busdeletea", value = "/Servlet_busdeletea")
public class Servlet_busdeletea extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String i=request.getParameter("id");
        System.out.println(i);
        int num= businessDao.deletea(Integer.parseInt(i));
        System.out.println(num);
        if(num>0){
            System.out.println("success");
        }else {
            System.out.println("dange");
        }
        response.sendRedirect("Servlet_businessdrop");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
