package ser;

import dao.DriverManagerDao;
import entity.customer;
import entity.psr;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_Updatapsr", value = "/Servlet_Updatapsr")
public class Servlet_Updatapsr extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id=request.getParameter("id");
        psr p= DriverManagerDao.selectonepsr(Integer.parseInt(id));
        System.out.println(p);
        request.setAttribute("psrid",p);
        request.getRequestDispatcher("updatapsr.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
