package ser;

import dao.enrollDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_enrollbus", value = "/Servlet_enrollbus")
public class Servlet_enrollbus extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username=request.getParameter("username");
        String password1=request.getParameter("password1");
        String password2=request.getParameter("password2");
        String name=request.getParameter("name");
        String business=request.getParameter("business");
        if(password1.equals(password2)){
            enrollDao e=  new enrollDao();
            e.enrollbus(username,password1,name,business);
        }else {
            response.sendRedirect("enroll3.jsp");
        }
    }
}
