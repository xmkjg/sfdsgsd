package ser;

import dao.businessDao;
import entity.record;
import entity.tea;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Servlet_busonerecord", value = "/Servlet_busonerecord")
public class Servlet_busonerecord extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String teaname=request.getParameter("teaname");
        List<tea>  r=businessDao.selectonerecords(teaname);
        System.out.println(r+"....");
        request.setAttribute("rlist",r);
        request.getRequestDispatcher("businsearch.jsp").forward(request,response);

    }
}
