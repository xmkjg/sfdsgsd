package ser;

import dao.DriverManagerDao;
import entity.customer;
import entity.psr;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_addpsr", value = "/Servlet_addpsr")
public class Servlet_addpsr extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        String name = request.getParameter("phone");

        String username = request.getParameter("psy");
        String password = request.getParameter("pwd");

        psr c = new psr();
        c.setPhone(name);
        c.setPsy(username);

        c.setPwd(password);
        int i = DriverManagerDao.psradd(c);
        if (i == 1) {
            System.out.println("success");
            response.sendRedirect("Servlet_psrdrop");
        }
    }

}
