package ser;

import dao.DriverManagerDao;
import entity.psr;
import entity.tea;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Servlet_goods", value = "/Servlet_goods")
public class Servlet_goods extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        List<tea> l=DriverManagerDao.selectalltea();
        System.out.println(l);
        request.setAttribute("tlist",l);
        request.getRequestDispatcher("admin.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
