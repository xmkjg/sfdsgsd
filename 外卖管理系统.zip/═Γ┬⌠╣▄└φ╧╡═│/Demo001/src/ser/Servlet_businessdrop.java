package ser;

import dao.DriverManagerDao;
import dao.businessDao;
import dao.customerDao;
import entity.business;
import entity.tea;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Servlet_businessdrop", value = "/Servlet_businessdrop")
public class Servlet_businessdrop extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        List<tea> list= customerDao.selectalltea();
        System.out.println(list);
        request.setAttribute("list",list);

        request.getRequestDispatcher("businessindex.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
