package ser;

import dao.DriverManagerDao;
import entity.business;
import entity.customer;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Servlet_customerdrop", value = "/Servlet_customerdrop")
public class Servlet_customerdrop extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        List<customer> list= DriverManagerDao.selectallcus();
        System.out.println(list);
        request.setAttribute("list",list);
        request.getRequestDispatcher("customer.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
