package ser;

import dao.DriverManagerDao;
import entity.business;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_addbus", value = "/Servlet_addbus")
public class Servlet_addbus extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        String name=request.getParameter("business_name");
        String person=request.getParameter("business_person");
        String username=request.getParameter("business_no");
        String password=request.getParameter("business_pwd");
        System.out.println(name+person+username+password);
       business b= new business();
       b.setBusiness_pwd(password);
       b.setBusiness_no(username);
       b.setBusiness_person(person);
       b.setBusiness_name(name);
      int i= DriverManagerDao.businessadd(b);
      if(i==1){
          System.out.println("success");
          response.sendRedirect("Servlet_busdrop");
      }
    }
}
