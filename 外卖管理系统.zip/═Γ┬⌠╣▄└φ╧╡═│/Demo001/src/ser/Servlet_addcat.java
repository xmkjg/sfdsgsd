package ser;

import dao.customerDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_addcat", value = "/Servlet_addcat")
public class Servlet_addcat extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String tea_name=request.getParameter("id");
        String tea_type=request.getParameter("id2");
        String username=request.getParameter("user");
        int i= customerDao.catadd(tea_name,tea_type,username);
        if (i>0){
            System.out.println("success");
        }else {
            System.out.println("dange");
        }
        response.sendRedirect("Servlet_customerindex");

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
