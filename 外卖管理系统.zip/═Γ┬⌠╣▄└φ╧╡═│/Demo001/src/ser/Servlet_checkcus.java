package ser;

import dao.DriverManagerDao;
import entity.business;
import entity.customer;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_checkcus", value = "/Servlet_checkcus")
public class Servlet_checkcus extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String cusname=request.getParameter("cusname");
        customer c= DriverManagerDao.selectonecus(cusname);
        System.out.println(c);
        request.setAttribute("cuslist",c);
        request.getRequestDispatcher("designatedcus.jsp").forward(request,response);
    }
}
