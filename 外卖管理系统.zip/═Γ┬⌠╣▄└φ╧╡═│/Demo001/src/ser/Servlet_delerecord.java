package ser;

import dao.DriverManagerDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_delerecord", value = "/Servlet_delerecord")
public class Servlet_delerecord extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String i=request.getParameter("id2");
        System.out.println(i);
        int num= DriverManagerDao.delerecord(Integer.parseInt(i));
        System.out.println(num);
        if(num>0){
            System.out.println("success");
        }else {
            System.out.println("dange");
        }
        response.sendRedirect("Servlet_recorddrop");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
