package ser;

import dao.DriverManagerDao;
import entity.business;
import entity.customer;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_Updatacus", value = "/Servlet_Updatacus")
public class Servlet_Updatacus extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id=request.getParameter("id");
        customer c= DriverManagerDao.selectonecus(Integer.parseInt(id));
        System.out.println(c);
        request.setAttribute("customerid",c);
        request.getRequestDispatcher("updatacus.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
