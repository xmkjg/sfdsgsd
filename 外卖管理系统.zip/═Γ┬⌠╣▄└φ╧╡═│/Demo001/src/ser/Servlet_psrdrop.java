package ser;

import dao.DriverManagerDao;
import entity.business;
import entity.psr;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Servlet_psrdrop", value = "/Servlet_psrdrop")
public class Servlet_psrdrop extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        List<psr> list= DriverManagerDao.selectallpsr();
        System.out.println(list);
        request.setAttribute("list",list);
        request.getRequestDispatcher("psr.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
