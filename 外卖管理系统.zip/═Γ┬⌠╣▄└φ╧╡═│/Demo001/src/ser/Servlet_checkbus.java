package ser;

import dao.DriverManagerDao;
import entity.business;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Servlet_checkbus", value = "/Servlet_checkbus")
public class Servlet_checkbus extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String busname=request.getParameter("busname");
      business b= DriverManagerDao.selectbus(busname);
        System.out.println(b);
        request.setAttribute("buslist",b);
        request.getRequestDispatcher("designatedbus.jsp").forward(request,response);
    }
}
