package ser;

import dao.customerDao;
import entity.customer;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_buytea", value = "/Servlet_buytea")
public class Servlet_buytea extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String id=request.getParameter("id");
        String id2=request.getParameter("id2");
String username=request.getParameter("user");
        System.out.println(id+id2+username);
int num=customerDao.recordadd(id,id2,username);
if(num>0){
    System.out.println("success");
}else {
    System.out.println("dange");
}
response.sendRedirect("Servlet_customerindex");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
