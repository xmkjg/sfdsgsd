package ser;

import dao.enrollDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_enrollpsr", value = "/Servlet_enrollpsr")
public class Servlet_enrollpsr extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String phone=request.getParameter("phone");
        String password1=request.getParameter("password1");
        String password2=request.getParameter("password2");
        String username=request.getParameter("username");
        if(password1.equals(password2)){
            enrollDao e=  new enrollDao();
            e.enrollpsr(username,password1,phone);
        }else {
            response.sendRedirect("enroll4.jsp");
        }
    }
}
