package ser;

import dao.customerDao;
import entity.cat;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Servlet_cat", value = "/Servlet_cat")
public class Servlet_cat extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

       List<cat> c=customerDao.selectcat();
       request.setAttribute("catlist",c);
       request.getRequestDispatcher("cat.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
