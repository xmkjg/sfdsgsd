package ser;

import dao.DriverManagerDao;
import entity.business;
import entity.customer;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_savecusupdata", value = "/Servlet_savecusupdata")
public class Servlet_savecusupdata extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String id=request.getParameter("id");
        String name=request.getParameter("customer_name");
        String username=request.getParameter("customer_no");
        String password=request.getParameter("customer_pwd");


        customer c=  new customer();
        c.setId(Integer.parseInt(id));
        c.setCustomer_name(name);
      c.setCustomer_no(username);
       c.setCustomer_pwd(password);


        int a= DriverManagerDao.updatacustomer(c);
        if(a==1){
            request.setAttribute("sucess","保存成功");
            System.out.println("sucess");
        }else {
            request.setAttribute("danger","保存失败");
            System.out.println("danger");
        }
        response.sendRedirect("Servlet_customerdrop");

    }
    }

