package ser;

import dao.customerDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_catbuytea", value = "/Servlet_catbuytea")
public class Servlet_catbuytea extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String tea_name=request.getParameter("tea_name");
        String tea_type=request.getParameter("tea_type");
        String name=request.getParameter("name");
        String id=request.getParameter("id");
       int i= customerDao.recordcatadd(tea_name,tea_type,name);
      int j= customerDao.delecat(Integer.parseInt(id));
       if(i>0&&j>0){
           System.out.println("success");
       }else {
           System.out.println("dange");
       }
       response.sendRedirect("Servlet_customerindex");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
