package ser;

import dao.DriverManagerDao;
import entity.psr;
import entity.record;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Servlet_checkrecord", value = "/Servlet_checkrecord")
public class Servlet_checkrecord extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String psrname=request.getParameter("teaname");
        List<record> c= DriverManagerDao.selectrecord(psrname);
        System.out.println(c);
        request.setAttribute("recordlist",c);
        request.getRequestDispatcher("designatedrecord.jsp").forward(request,response);
    }
}
