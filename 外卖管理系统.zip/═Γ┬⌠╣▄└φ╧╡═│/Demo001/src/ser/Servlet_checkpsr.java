package ser;

import dao.DriverManagerDao;
import entity.customer;
import entity.psr;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_checkpsr", value = "/Servlet_checkpsr")
public class Servlet_checkpsr extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String psrname=request.getParameter("psrname");
        psr c= DriverManagerDao.selectpsr(psrname);
        System.out.println(c);
        request.setAttribute("psrlist",c);
        request.getRequestDispatcher("designatedpsr.jsp").forward(request,response);
    }
}
