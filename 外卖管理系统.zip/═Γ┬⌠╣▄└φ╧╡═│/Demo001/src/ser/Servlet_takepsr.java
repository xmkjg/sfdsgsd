package ser;

import dao.psrDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_takepsr", value = "/Servlet_takepsr")
public class Servlet_takepsr extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       String name=request.getParameter("id");
        String id=request.getParameter("id2");
        System.out.println(name+id);
        int num=psrDao.updatastate(name,Integer.parseInt(id));
        if (num>0){
            System.out.println("success");
        }else {
            System.out.println("err");
        }
        response.sendRedirect("Servlet_psrindex");

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
