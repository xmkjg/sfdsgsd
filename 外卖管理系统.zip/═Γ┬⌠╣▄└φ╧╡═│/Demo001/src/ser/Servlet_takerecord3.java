package ser;

import dao.businessDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_takerecord3", value = "/Servlet_takerecord3")
public class Servlet_takerecord3 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String no=request.getParameter("id1");
        String state=request.getParameter("id2");
        int num= businessDao.updataserchstate(no,state);
        if(num>0){
            System.out.println("success");
        }else {
            System.out.println("take out");
        }
        response.sendRedirect("Servlet_busTorders");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
