package ser;

import dao.DriverManagerDao;
import entity.customer;
import entity.psr;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_savepsrupdata", value = "/Servlet_savepsrupdata")
public class Servlet_savepsrupdata extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String id=request.getParameter("id");

        String password=request.getParameter("psr_pwd");


        psr c=  new psr();
        c.setId(Integer.parseInt(id));

        c.setPwd(password);


        int a= DriverManagerDao.updatapsr(c);
        if(a==1){
            request.setAttribute("sucess","保存成功");
            System.out.println("sucess");
        }else {
            request.setAttribute("danger","保存失败");
            System.out.println("danger");
        }
        response.sendRedirect("Servlet_psrdrop");

    }
    }

