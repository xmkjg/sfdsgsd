package ser;

import dao.DriverManagerDao;
import entity.business;
import entity.customer;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_addcus", value = "/Servlet_addcus")
public class Servlet_addcus extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        String name = request.getParameter("customer_name");

        String username = request.getParameter("customer_no");
        String password = request.getParameter("customer_pwd");

        customer c = new customer();
        c.setCustomer_name(name);
        c.setCustomer_no(username);

        c.setCustomer_pwd(password);
        int i = DriverManagerDao.customeradd(c);
        if (i == 1) {
            System.out.println("success");
            response.sendRedirect("Servlet_customerdrop");
        }
    }
}