package ser;

import dao.DriverManagerDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_delecus", value = "/Servlet_delecus")
public class Servlet_delecus extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String i=request.getParameter("id2");
        System.out.println(i);
        int num= DriverManagerDao.delecustomer(Integer.parseInt(i));
        System.out.println(num);
        if(num>0){
            System.out.println("success");
        }else {
            System.out.println("dange");
        }
        response.sendRedirect("Servlet_customerdrop");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
