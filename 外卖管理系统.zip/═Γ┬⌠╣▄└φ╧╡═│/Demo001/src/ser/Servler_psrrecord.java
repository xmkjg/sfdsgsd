package ser;

import dao.psrDao;
import entity.record;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Servler_psrrecord", value = "/Servler_psrrecord")
public class Servler_psrrecord extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

       String psrname= request.getParameter("name");
       List<record> r=psrDao.selectrecord(psrname);
       request.setAttribute("psrrecord",r);
       request.getRequestDispatcher("psrrecord.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
