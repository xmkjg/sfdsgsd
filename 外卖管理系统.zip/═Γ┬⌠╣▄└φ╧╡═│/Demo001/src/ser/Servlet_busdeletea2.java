package ser;

import dao.businessDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_busdeletea2", value = "/Servlet_busdeletea2")
public class Servlet_busdeletea2 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name=request.getParameter("id");
        String type=request.getParameter("id2");
        String goods=request.getParameter("id3");
        System.out.println(name+type+goods);
        int num= businessDao.delethreetea(name,type,goods);
        System.out.println(num);
        if(num>0){
            System.out.println("success");
        }else {
            System.out.println("dange");
        }
        response.sendRedirect("Servlet_businessdrop");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
