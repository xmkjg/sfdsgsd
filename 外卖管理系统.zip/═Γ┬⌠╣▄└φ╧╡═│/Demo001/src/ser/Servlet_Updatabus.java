package ser;

import dao.DriverManagerDao;
import entity.business;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_Updatabus", value = "/Servlet_Updatabus")
public class Servlet_Updatabus extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id=request.getParameter("id");
       business b= DriverManagerDao.selectonebus(Integer.parseInt(id));
        System.out.println(b);
       request.setAttribute("businessid",b);
       request.getRequestDispatcher("updatabus.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
