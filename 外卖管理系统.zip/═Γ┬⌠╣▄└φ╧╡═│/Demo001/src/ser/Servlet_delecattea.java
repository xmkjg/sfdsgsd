package ser;

import dao.customerDao;
import entity.customer;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_delecattea", value = "/Servlet_delecattea")
public class Servlet_delecattea extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
String id=request.getParameter("id");
       int i= customerDao.delecat(Integer.parseInt(id));
       if(i>0){
           System.out.println("success");
       }else {
           System.out.println("dange");
       }
       response.sendRedirect("Servlet_cat");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
