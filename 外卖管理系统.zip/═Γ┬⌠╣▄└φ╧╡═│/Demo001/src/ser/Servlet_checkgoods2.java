package ser;

import dao.customerDao;
import entity.tea;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Servlet_checkgoods2", value = "/Servlet_checkgoods2")
public class Servlet_checkgoods2 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String teaname=request.getParameter("teaname");
        System.out.println(teaname+"....");
        tea t= customerDao.selectgoods(teaname);
        System.out.println(t);
        request.setAttribute("tea",t);
        request.getRequestDispatcher("checktea2.jsp").forward(request,response);
    }
}
