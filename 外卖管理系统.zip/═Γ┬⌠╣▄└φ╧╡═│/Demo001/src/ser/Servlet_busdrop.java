package ser;

import dao.DriverManagerDao;
import entity.business;
import entity.tea;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Servlet_busdrop", value = "/Servlet_busdrop")
public class Servlet_busdrop extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        List<business> list= DriverManagerDao.selectallbus();
        System.out.println(list);
        request.setAttribute("list",list);

        List<tea> l=DriverManagerDao.selectalltea();
        System.out.println(l);
        request.setAttribute("tealist",l);
        request.getRequestDispatcher("business.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
