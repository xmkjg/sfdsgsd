package utils;

import java.sql.*;

public class DBUtil {
    public  static Connection getConnnection(String url,String username,String password){
        Connection conn=null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
        }catch (ClassNotFoundException e){
            e.printStackTrace();
            System.out.println("not");
        }
        try{
            conn= DriverManager.getConnection(url,username,password);

        }catch (SQLException e){
e.printStackTrace();

        }
        return conn;
    }

    public static void close(Connection conn, PreparedStatement stmt, ResultSet rs){
        if (rs!=null){
            try{
               rs.close();
            }catch (SQLException e){
                e.printStackTrace();

            }
        }
        if (conn!=null){
            try{
                conn.close();
            }catch (SQLException e){
                e.printStackTrace();

            }
        }
        if (stmt!=null){
            try{
                stmt.close();
            }catch (SQLException e){
                e.printStackTrace();

            }
        }

    }
}
