package entity;

public class tea {
    private int id;
    private String business_name;
    private String business_cp;
    private String business_type;
    private int business_id;
    private String time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBusiness_name() {
        return business_name;
    }

    public void setBusiness_name(String business_name) {
        this.business_name = business_name;
    }

    public String getBusiness_cp() {
        return business_cp;
    }

    public void setBusiness_cp(String business_cp) {
        this.business_cp = business_cp;
    }

    public String getBusiness_type() {
        return business_type;
    }

    public void setBusiness_type(String business_type) {
        this.business_type = business_type;
    }

    public int getBusiness_id() {
        return business_id;
    }

    public void setBusiness_id(int business_id) {
        this.business_id = business_id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public tea( String business_name, String business_cp, String business_type,String time) {

        this.business_name = business_name;
        this.business_cp = business_cp;
        this.business_type = business_type;

        this.time = time;
    }

    public tea(String business_name, String business_cp, String business_type, int business_id, String time) {

        this.business_name = business_name;
        this.business_cp = business_cp;
        this.business_type = business_type;
        this.business_id = business_id;
        this.time = time;
    }

    public tea(int id, String business_name, String business_cp, String business_type, int business_id, String time) {
        this.id = id;
        this.business_name = business_name;
        this.business_cp = business_cp;
        this.business_type = business_type;
        this.business_id = business_id;
        this.time = time;
    }
    public tea(int id, String business_name, String business_cp, String business_type,  String time) {
        this.id = id;
        this.business_name = business_name;
        this.business_cp = business_cp;
        this.business_type = business_type;

        this.time = time;
    }
    public tea() {
    }
}
