package entity;

public class student {
    private int student_id;
    private String student_name;
    private String student_college;
    private String student_major;
    private int student_class;
    private String student_tele;

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public String getStudent_name() {
        return student_name;
    }

    public void setStudent_name(String student_name) {
        this.student_name = student_name;
    }

    public String getStudent_college() {
        return student_college;
    }

    public void setStudent_college(String student_college) {
        this.student_college = student_college;
    }

    public String getStudent_major() {
        return student_major;
    }

    public void setStudent_major(String student_major) {
        this.student_major = student_major;
    }

    public int getStudent_class() {
        return student_class;
    }

    public void setStudent_class(int student_class) {
        this.student_class = student_class;
    }

    public String getStudent_tele() {
        return student_tele;
    }

    public void setStudent_tele(String student_tele) {
        this.student_tele = student_tele;
    }

    public student(int student_id, String student_name, String student_college, String student_major, int student_class, String student_tele) {
        this.student_id = student_id;
        this.student_name = student_name;
        this.student_college = student_college;
        this.student_major = student_major;
        this.student_class = student_class;
        this.student_tele = student_tele;
    }

    public student() {
    }
}
