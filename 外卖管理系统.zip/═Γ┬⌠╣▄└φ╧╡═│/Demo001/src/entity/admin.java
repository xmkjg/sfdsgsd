package entity;

public class admin {
    private String id;
    private String userName;
    private String nickName;
    private String pwd;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public admin(String id, String userName, String nickName, String pwd) {
        this.id = id;
        this.userName = userName;
        this.nickName = nickName;
        this.pwd = pwd;
    }

    public admin( String userName, String pwd) {

        this.userName = userName;

        this.pwd = pwd;
    }
    public admin() {
    }
}
