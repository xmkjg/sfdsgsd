package entity;

public class cat {
    private int id;
    private String tea_type;
    private String tea_name;
    private  String username;
    private String time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTea_type() {
        return tea_type;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setTea_type(String tea_type) {
        this.tea_type = tea_type;
    }

    public String getTea_name() {
        return tea_name;
    }

    public void setTea_name(String tea_name) {
        this.tea_name = tea_name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public cat(int id, String tea_type, String tea_name, String username,String time) {
        this.id = id;
        this.tea_type = tea_type;
        this.tea_name = tea_name;
        this.username = username;
        this.time=time;
    }
}
