package entity;

public class record {
    private int id;
    private int tea_id;
    private String tea_name;
    private String tea_type;
    private String no;
    private String userName;
    private int userId;
    private String time;
    private String state;
    private int psrId;
    private String psrName;

    public int getTea_id() {
        return tea_id;
    }

    public void setTea_id(int tea_id) {
        this.tea_id = tea_id;
    }

    public String getTea_name() {
        return tea_name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTea_name(String tea_name) {
        this.tea_name = tea_name;
    }

    public String getTea_type() {
        return tea_type;
    }

    public void setTea_type(String tea_type) {
        this.tea_type = tea_type;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public int getPsrId() {
        return psrId;
    }

    public void setPsrId(int psrId) {
        this.psrId = psrId;
    }

    public String getPsrName() {
        return psrName;
    }

    public void setPsrName(String psrName) {
        this.psrName = psrName;
    }

    public record( String tea_name, String tea_type, String no, String userName, int userId, String time, String state, int psrId, String psrName) {


        this.tea_name = tea_name;
        this.tea_type = tea_type;
        this.no = no;
        this.userName = userName;
        this.userId = userId;
        this.time = time;
        this.state = state;
        this.psrId = psrId;
        this.psrName = psrName;
    }

    public record(int id, String tea_name, String tea_type, String no, String userName, String time, String state, String psrName) {
        this.id = id;
        this.tea_name = tea_name;
        this.tea_type = tea_type;
        this.no = no;
        this.userName = userName;
        this.time = time;
        this.state = state;
        this.psrName = psrName;
    }

    public record( int id,String tea_name, String tea_type, String userName,  String time,String state, String psrName) {

         this.id=id;
        this.tea_name=tea_name;
        this.tea_type = tea_type;
        this.time = time;
        this.state = state;
this.userName=userName;
        this.psrName = psrName;
    }

    public record(String state){
        this.state=state;
}
    public record() {
    }
}
