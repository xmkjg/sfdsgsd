package entity;

public class customer {
    private int id;
    private String customer_name;
    private String customer_no;
    private String customer_pwd;
    private String time;

    public String getCustomer_name() {
        return customer_name;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCustomer_no() {
        return customer_no;
    }

    public void setCustomer_no(String customer_no) {
        this.customer_no = customer_no;
    }

    public String getCustomer_pwd() {
        return customer_pwd;
    }

    public void setCustomer_pwd(String customer_pwd) {
        this.customer_pwd = customer_pwd;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public customer( int id,String customer_name, String customer_no, String customer_pwd, String time) {
        this.id=id;
        this.customer_name = customer_name;
        this.customer_no = customer_no;
        this.customer_pwd = customer_pwd;
        this.time = time;
    }
    public customer( String customer_name, String customer_no, String customer_pwd, String time) {

        this.customer_name = customer_name;
        this.customer_no = customer_no;
        this.customer_pwd = customer_pwd;
        this.time = time;
    }
    public customer() {
    }
}
