package entity;

public class psr {
    private  int id;


    private String psy;
    private String pwd;

    private String phone;
    private String time;


    public String getPsy() {
        return psy;
    }

    public void setPsy(String psy) {
        this.psy = psy;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }



    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }



    public psr( int id,String psy, String pwd,  String phone, String time) {
this.id=id;
        this.psy = psy;
        this.pwd = pwd;

        this.phone = phone;
        this.time = time;

    }
    public psr( String psy, String pwd,  String phone, String time) {
        this.id=id;
        this.psy = psy;
        this.pwd = pwd;

        this.phone = phone;
        this.time = time;

    }
public psr(String psy){
        this.psy=psy;
}
    public psr() {
    }
}
