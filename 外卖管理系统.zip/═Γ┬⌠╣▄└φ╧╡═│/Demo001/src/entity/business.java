package entity;

public class business {
    private int id;
    private String business_name;
    private String business_person;
    private String time;
    private String business_no;
    private String business_pwd;

    public String getBusiness_name() {
        return business_name;
    }

    public void setBusiness_name(String business_name) {
        this.business_name = business_name;
    }

    public String getBusiness_person() {
        return business_person;
    }

    public void setBusiness_person(String business_person) {
        this.business_person = business_person;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBusiness_no() {
        return business_no;
    }

    public void setBusiness_no(String business_no) {
        this.business_no = business_no;
    }

    public String getBusiness_pwd() {
        return business_pwd;
    }

    public void setBusiness_pwd(String business_pwd) {
        this.business_pwd = business_pwd;
    }

    public business(String business_name, String business_person, String time, String business_no, String business_pwd) {

        this.business_name = business_name;
        this.business_person = business_person;
        this.time = time;
        this.business_no = business_no;
        this.business_pwd = business_pwd;
    }
    public business(int id,String business_name, String business_person, String time, String business_no, String business_pwd) {
this.id=id;
        this.business_name = business_name;
        this.business_person = business_person;
        this.time = time;
        this.business_no = business_no;
        this.business_pwd = business_pwd;
    }

    public business() {
    }
}
